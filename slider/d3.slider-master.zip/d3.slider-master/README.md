D3.js Slider
============

This is a pure D3.js slider inspired by the <a href="">jQuery UI Slider</a>. Supports <a href="https://github.com/mbostock/d3/wiki/SVG-Axes">D3’s axis component</a>. Feel free to contribute!

<a href="http://thematicmapping.org/playground/d3/d3.slider/">Examples</a>
